function toggleMode() {
    const body = document.querySelector('body');
    body.classList.toggle('dark-mode');
}
